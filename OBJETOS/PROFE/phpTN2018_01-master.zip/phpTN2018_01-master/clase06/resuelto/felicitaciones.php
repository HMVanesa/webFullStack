<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Felicitaciones</title>
	</head>
	<body>
		<h2>Datos enviados :D</h2>
	</body>
</html>
