# Modulo PHP Estructurado
Repositorio parcial con los archivos y ejercicios vistos en clase hasta el momento. Cada carpeta contiene los archivos utilizados y así mismo sus resoluciones.

### Enjoy it!

![The horns emoji](http://www.metalinjection.net/wp-content/uploads/2015/06/metal-horn-emoji.jpg)
