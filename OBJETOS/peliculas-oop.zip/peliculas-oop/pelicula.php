<?php
  class pelicula {
    private $Id;
    private $Actores;

    public $titulo;
    public $rating;

    public function __construct($IdInicial, $TituloInicial, $RatingInicial, $ActoresIniciales) {
      $this->Id=$IdInicial;
      $this->titulo=$TituloInicial;
      $this->rating=$RatingInicial;
      $this->Actores=$ActoresIniciales;
    }

    public function getId() {
      return $this->Id;
    }

    public function getCantidadActores() {
      return count($this->Actores);
    }

    public function getNombreActores() {
      if (count($this->Actores)>0) {
        $Nombres="";
        foreach ($this->Actores as $NombreUnActor) {
          $Nombres = "{$Nombres} {$NombreUnActor} - ";
        }
      } else {
        $Nombres="No tiene actores registrados";
      }
      return $Nombres;
    }
  }

?>
