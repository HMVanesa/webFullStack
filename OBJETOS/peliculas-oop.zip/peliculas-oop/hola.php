<html>
 <head>
 <?php

    require_once("pelicula.php");
    require_once("peliculas.php");

    $MisPeliculas=Peliculas::ObtenerTodas();

    $CantidadPeliculas=Peliculas::$Cantidad;

    echo "Tengo <b>{$CantidadPeliculas}</b> peliculas<br><br>";

    $PeliDeMejorRating = Peliculas::getLaDeMejorRating();
    echo "La peli de mejor rating se llama <b>{$PeliDeMejorRating->titulo}</b> y su rating es <b>{$PeliDeMejorRating->rating}</b><br><br>";

    foreach ($MisPeliculas as $UnaPeli) {
      echo "Una peli se llama <b>{$UnaPeli->titulo}</b><br>";
      echo "Su rating fue <b>{$UnaPeli->rating}</b><br>";
      echo "Su Id es <b>{$UnaPeli->getId()}</b><br>";
      echo "Tiene <b>{$UnaPeli->getCantidadActores()}</b> actores<br>";
      echo "Sus actores se llaman: {$UnaPeli->getNombreActores()}<br>";

      echo "<hr>";

    }


/*

require_once("connect.php");

$CadenaDeBusqueda = "SELECT title, rating FROM movies";
$ConsultaALaBase = $db->prepare($CadenaDeBusqueda);
$ConsultaALaBase->execute();

$MisPeliculas=array();

while ($UnRegistro = $ConsultaALaBase->fetch(PDO::FETCH_ASSOC)) {
  $UnaPeli = new pelicula();
  $UnaPeli->titulo=$UnRegistro['title'];
  $UnaPeli->rating=$UnRegistro['rating'];

  $MisPeliculas[] = $UnaPeli;

}

    $UnPlato = new plato();

    $UnPlato->nombre="BigMac";

    $UnPlato->setPrecio(80);
    echo "Mi plato es un {$UnPlato->nombre}, cuesta $ {$UnPlato->getPrecio()}, y pesa {$UnPlato->peso} gramos.";
    $UnPlato->setPrecio(1);
    echo "Mi plato es un {$UnPlato->nombre}, cuesta $ {$UnPlato->getPrecio()}, y pesa {$UnPlato->peso} gramos.";

    $UnPlato->peso=500;


    $UnHamburguesa = new hamburguesa();
    $UnHamburguesa->nombre="Stalker 3";
    $UnHamburguesa->CantidadCarnes=3;
    $UnHamburguesa->PuntoCoccion="medio";
    //$UnHamburguesa->estaPreparado=true;

    $UnHamburguesa->preparar();

    echo "<br><br>Mi hamb es un {$UnHamburguesa->nombre}, y su punto de cocción es {$UnHamburguesa->PuntoCoccion}";

    echo "<br><br>Mi hamb está preparada?  {$UnHamburguesa->getPreparado()}";


















    require_once 'plato.php';
    require_once 'ensaladas.php';

    $EnsaladaAmericana = new Ensaladas();

    $EnsaladaAmericana->nombre="aaa";
    echo $EnsaladaAmericana->nombre;

    $BigMac = new plato();

    echo "Mi plato es un {$BigMac->nombre}, cuesta $ {$BigMac->precio}-, y pesa {$BigMac->peso} gramos";

    $BigMac->nombre="Hamburguesa";
    $BigMac->precio=90;
    $BigMac->peso=500;

    echo "<br><br>Mi plato es un {$BigMac->nombre}, cuesta $ {$BigMac->precio}-, y pesa {$BigMac->peso} gramos";

    echo "<br><br>Está preparado?  Eh?  {$BigMac->getPreparado()}";

    $BigMac->Preparar();

    echo "<br><br>Está preparado?  Eh?  {$BigMac->getPreparado()}";



     $MiAuto=new Auto("Ford", "Rojo");

     $MiAuto->setMarca("Citroen");
     $MiAuto->color="Rojo";
     $MiAuto->kilometraje=50000;

     $MiAuto->FalsearKilometraje();
     echo "Tengo un auto marca {$MiAuto->getMarca()} que cuando no está sucio se ve que es de color {$MiAuto->kilometraje}";

     echo "<br>";
     if ($MiAuto->GuardarEnBase() == true) {
       echo "Se guardó correctamente";
     } else {
       echo "Ouch!";
     }
*/

      ?>
 </body>
</html>
