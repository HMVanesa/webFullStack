<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<form  action="recibir.php" method="post">
			<input type="text" name="nombre" value="" placeholder="nombre">
			<br><br>
			<button type="submit">Enviar</button>
		</form>
	</body>
</html>
