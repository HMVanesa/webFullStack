<?php
	echo '<strong>Hola mundo, desde saludo.php</strong>';
